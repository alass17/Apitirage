package com.apitirage.ApiTirage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTirageApplicationTests {

	@Test
	void contextLoads() {
	}

}
