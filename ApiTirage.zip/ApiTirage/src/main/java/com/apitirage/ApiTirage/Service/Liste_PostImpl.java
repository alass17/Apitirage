package com.apitirage.ApiTirage.Service;

import com.apitirage.ApiTirage.Models.Liste_Post;
import com.apitirage.ApiTirage.Repository.Liste_PostRepo;
import com.apitirage.ApiTirage.Repository.PostulantRepo;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@AllArgsConstructor
@Service
public class Liste_PostImpl implements Liste_PostService {

}