package com.apitirage.ApiTirage.Repository;

import com.apitirage.ApiTirage.Models.Postulant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostulantRepo extends JpaRepository<Postulant,Long> {
}
