package com.apitirage.ApiTirage.Repository;

import com.apitirage.ApiTirage.Models.Liste_Post;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Liste_PostRepo extends JpaRepository<Liste_Post,Long> {

}
