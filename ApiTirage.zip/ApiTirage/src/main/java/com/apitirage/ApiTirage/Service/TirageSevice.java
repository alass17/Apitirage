package com.apitirage.ApiTirage.Service;

import com.apitirage.ApiTirage.Models.Tirage;

public interface TirageSevice {
    Tirage trier (Tirage tirage);
}
