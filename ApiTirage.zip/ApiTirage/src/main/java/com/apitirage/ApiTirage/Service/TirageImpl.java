package com.apitirage.ApiTirage.Service;

import com.apitirage.ApiTirage.Models.Tirage;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@AllArgsConstructor
@Service

public class TirageImpl implements TirageSevice{

    @Override
    public Tirage trier(Tirage tirage) {
        return null;
    }
}
