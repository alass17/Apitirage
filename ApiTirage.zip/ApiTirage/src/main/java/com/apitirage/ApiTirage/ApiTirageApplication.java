package com.apitirage.ApiTirage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class ApiTirageApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiTirageApplication.class, args);
	}


	}

