package com.apitirage.ApiTirage.Service;

public interface Liste_PostService {

}
